<title>Pillar | Buddhist Parinay</title>

<!-- About Section -->
<div class="w3-row w3-padding-large" id="about" style="margin-top: 80px">
	<div class="w3-col m6 w3-padding-large ">
		<h1 class="w3-center" style="color: #5E32E1;">Our Pillar</h1><br>
		
		<div class="w3-col l12 w3-margin-top">
			<h4 class=""><b>Mrs. Vidya Sunil Taware</b><br>B.COM.LLB GDC. AMC,PUNE</h4>
			<p>
				In this journey of <b>Buddhist Parinay</b>, Mrs Vidya Sunil Taware is our big supporter and 
				one of the source of priceless guidance.
			</p>
			<p>
				Meanwhile, She has also worked as a counselor in her profession and also been a vital part of 
				contribution in our work.
				So we express our kind gratitude and are very thankful for her valuable guidance.
			</p>
		</div>
		
	</div>

	<div class="w3-col m6 w3-padding-large">
		<img src="<?php echo base_url(); ?>assets/demo/images/piller_vidya.jpg" class="w3-round w3-image w3-opacity-min" alt="Table Setting" width="600" height="750">
	</div>
</div>
